package com.gofun.ms.${project.artifact}.mapper;

public class DemoMapper {

}
